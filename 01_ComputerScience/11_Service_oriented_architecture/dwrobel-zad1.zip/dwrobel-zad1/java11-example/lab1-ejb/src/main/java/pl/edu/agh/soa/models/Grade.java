package pl.edu.agh.soa.models;

import javax.xml.bind.annotation.XmlElement;
import java.util.Objects;

public class Grade {

    @XmlElement
    public String subject;

    @XmlElement
    public double value;

    public Grade(String subject, double value) {
        this.subject = subject;
        this.value = value;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Grade grade = (Grade) o;
        return Double.compare(grade.value, value) == 0 &&
                Objects.equals(subject, grade.subject);
    }

    @Override
    public int hashCode() {
        return Objects.hash(subject, value);
    }
}
