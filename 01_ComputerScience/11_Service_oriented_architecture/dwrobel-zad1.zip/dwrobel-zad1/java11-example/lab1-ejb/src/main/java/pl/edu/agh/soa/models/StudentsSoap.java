package pl.edu.agh.soa.models;

import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

public class StudentsSoap {

    @XmlElement(name = "student")
    public List<Student> students;

    public StudentsSoap() {
        this.students = new ArrayList<>();
        Student student1 = new Student("Dominik", "Wrobel", "123456", "EAIIB");
        student1.grades.add(new Grade("SOA", 5.0));
        student1.grades.add(new Grade("Python", 4.0));

        Student student2 = new Student("Franek", "Sosna", "123123", "IMIR");
        student2.grades.add(new Grade("SOA", 4.5));
        student2.grades.add(new Grade("Python", 3.0));

        Student student3 = new Student("Lucyna", "Kopytko", "456456", "EAIIB");
        student3.grades.add(new Grade("SOA", 3.5));
        student3.grades.add(new Grade("Python", 4.0));

        Student student4 = new Student("Marek", "Suchar", "143143", "IMIR");
        student4.grades.add(new Grade("SOA", 5.0));
        student4.grades.add(new Grade("Python", 5.0));

        Student student5 = new Student("Zofia", "Rutyna", "543543", "EAIIB");
        student5.grades.add(new Grade("SOA", 4.5));
        student5.grades.add(new Grade("Python", 4.5));

        Student student6 = new Student("Kamila", "Tarka", "124124", "IMIR");
        student6.grades.add(new Grade("SOA", 3.0));
        student6.grades.add(new Grade("Python", 3.0));

        students.add(student1);
        students.add(student2);
        students.add(student3);
        students.add(student4);
        students.add(student5);
        students.add(student6);
    }

}
