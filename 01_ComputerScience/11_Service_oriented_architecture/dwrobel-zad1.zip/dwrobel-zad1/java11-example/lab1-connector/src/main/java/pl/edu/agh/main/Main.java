package pl.edu.agh.main;

import pl.edu.agh.soa.HelloWorld;
import pl.edu.agh.soa.HelloWorldService;
import pl.edu.agh.soa.Student;
import pl.edu.agh.soa.StudentsSoap;

import javax.imageio.ImageIO;
import javax.xml.ws.BindingProvider;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;

public class Main {

    public static void setCredentials(HelloWorld helloWorld){
        BindingProvider bindingProvider = (BindingProvider) helloWorld;
        bindingProvider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, "dom");
        bindingProvider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, "dom");
    }


    public static void main(String[] args) throws IOException {
        System.out.println("Hello world");
        HelloWorldService helloWorldService = new HelloWorldService();
        HelloWorld helloWorld = helloWorldService.getHelloWorldPort();

        Main.setCredentials(helloWorld);

        // get list of all students
        StudentsSoap studentsSoap = helloWorld.getAllStudents();
        for(Student s : studentsSoap.getStudent()){
            System.out.println("Name: " + s.getName() + " ," + "Surname: " + s.getSurname() + " ,Index " + s.getIndexNumber());
        }

        // get and decode file
        String encodedImage = helloWorld.getStudentAvatar("123456");
        byte[] decodedImage= Base64.getDecoder().decode(encodedImage);
        ByteArrayInputStream bytesArr = new ByteArrayInputStream(decodedImage);
        BufferedImage bImage = ImageIO.read(bytesArr);
        ImageIO.write(bImage, "png", new File("C:\\Users\\Dominik\\Desktop\\SOA\\Laboratorium_Rozwiązania\\Lab1_Rozwiazanie\\java11-example\\java11-example\\lab1-connector\\src\\main\\resources\\avatar.png") );

        // method requiring auth
        String result = helloWorld.addStudent("Test1", "Test1", "565445", "EAIIB");
        System.out.println("Student added " + result);

    }
}
