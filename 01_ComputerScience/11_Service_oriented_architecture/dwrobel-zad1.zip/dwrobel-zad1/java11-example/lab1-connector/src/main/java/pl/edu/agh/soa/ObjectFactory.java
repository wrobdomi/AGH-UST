
package pl.edu.agh.soa;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the pl.edu.agh.soa package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetStudentAvatarResponse_QNAME = new QName("http://soap.soa.agh.edu.pl/", "getStudentAvatarResponse");
    private final static QName _UpdateStudentFacultyResponse_QNAME = new QName("http://soap.soa.agh.edu.pl/", "updateStudentFacultyResponse");
    private final static QName _GetAllStudentsResponse_QNAME = new QName("http://soap.soa.agh.edu.pl/", "getAllStudentsResponse");
    private final static QName _GetStudentAvatar_QNAME = new QName("http://soap.soa.agh.edu.pl/", "getStudentAvatar");
    private final static QName _FilterByFacultyResponse_QNAME = new QName("http://soap.soa.agh.edu.pl/", "filterByFacultyResponse");
    private final static QName _AddStudent_QNAME = new QName("http://soap.soa.agh.edu.pl/", "addStudent");
    private final static QName _AddGradeToStudentResponse_QNAME = new QName("http://soap.soa.agh.edu.pl/", "addGradeToStudentResponse");
    private final static QName _GetAllStudents_QNAME = new QName("http://soap.soa.agh.edu.pl/", "getAllStudents");
    private final static QName _DeleteStudentResponse_QNAME = new QName("http://soap.soa.agh.edu.pl/", "deleteStudentResponse");
    private final static QName _FilterByFaculty_QNAME = new QName("http://soap.soa.agh.edu.pl/", "filterByFaculty");
    private final static QName _AddStudentResponse_QNAME = new QName("http://soap.soa.agh.edu.pl/", "addStudentResponse");
    private final static QName _DeleteStudent_QNAME = new QName("http://soap.soa.agh.edu.pl/", "deleteStudent");
    private final static QName _AddGradeToStudent_QNAME = new QName("http://soap.soa.agh.edu.pl/", "addGradeToStudent");
    private final static QName _UpdateStudentFaculty_QNAME = new QName("http://soap.soa.agh.edu.pl/", "updateStudentFaculty");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: pl.edu.agh.soa
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Student }
     * 
     */
    public Student createStudent() {
        return new Student();
    }

    /**
     * Create an instance of {@link FilterByFacultyResponse }
     * 
     */
    public FilterByFacultyResponse createFilterByFacultyResponse() {
        return new FilterByFacultyResponse();
    }

    /**
     * Create an instance of {@link AddStudent }
     * 
     */
    public AddStudent createAddStudent() {
        return new AddStudent();
    }

    /**
     * Create an instance of {@link GetStudentAvatar }
     * 
     */
    public GetStudentAvatar createGetStudentAvatar() {
        return new GetStudentAvatar();
    }

    /**
     * Create an instance of {@link DeleteStudentResponse }
     * 
     */
    public DeleteStudentResponse createDeleteStudentResponse() {
        return new DeleteStudentResponse();
    }

    /**
     * Create an instance of {@link AddGradeToStudentResponse }
     * 
     */
    public AddGradeToStudentResponse createAddGradeToStudentResponse() {
        return new AddGradeToStudentResponse();
    }

    /**
     * Create an instance of {@link GetAllStudents }
     * 
     */
    public GetAllStudents createGetAllStudents() {
        return new GetAllStudents();
    }

    /**
     * Create an instance of {@link GetStudentAvatarResponse }
     * 
     */
    public GetStudentAvatarResponse createGetStudentAvatarResponse() {
        return new GetStudentAvatarResponse();
    }

    /**
     * Create an instance of {@link GetAllStudentsResponse }
     * 
     */
    public GetAllStudentsResponse createGetAllStudentsResponse() {
        return new GetAllStudentsResponse();
    }

    /**
     * Create an instance of {@link UpdateStudentFacultyResponse }
     * 
     */
    public UpdateStudentFacultyResponse createUpdateStudentFacultyResponse() {
        return new UpdateStudentFacultyResponse();
    }

    /**
     * Create an instance of {@link UpdateStudentFaculty }
     * 
     */
    public UpdateStudentFaculty createUpdateStudentFaculty() {
        return new UpdateStudentFaculty();
    }

    /**
     * Create an instance of {@link AddStudentResponse }
     * 
     */
    public AddStudentResponse createAddStudentResponse() {
        return new AddStudentResponse();
    }

    /**
     * Create an instance of {@link DeleteStudent }
     * 
     */
    public DeleteStudent createDeleteStudent() {
        return new DeleteStudent();
    }

    /**
     * Create an instance of {@link FilterByFaculty }
     * 
     */
    public FilterByFaculty createFilterByFaculty() {
        return new FilterByFaculty();
    }

    /**
     * Create an instance of {@link AddGradeToStudent }
     * 
     */
    public AddGradeToStudent createAddGradeToStudent() {
        return new AddGradeToStudent();
    }

    /**
     * Create an instance of {@link StudentsSoap }
     * 
     */
    public StudentsSoap createStudentsSoap() {
        return new StudentsSoap();
    }

    /**
     * Create an instance of {@link Grade }
     * 
     */
    public Grade createGrade() {
        return new Grade();
    }

    /**
     * Create an instance of {@link Student.GradesList }
     * 
     */
    public Student.GradesList createStudentGradesList() {
        return new Student.GradesList();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStudentAvatarResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "getStudentAvatarResponse")
    public JAXBElement<GetStudentAvatarResponse> createGetStudentAvatarResponse(GetStudentAvatarResponse value) {
        return new JAXBElement<GetStudentAvatarResponse>(_GetStudentAvatarResponse_QNAME, GetStudentAvatarResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateStudentFacultyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "updateStudentFacultyResponse")
    public JAXBElement<UpdateStudentFacultyResponse> createUpdateStudentFacultyResponse(UpdateStudentFacultyResponse value) {
        return new JAXBElement<UpdateStudentFacultyResponse>(_UpdateStudentFacultyResponse_QNAME, UpdateStudentFacultyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllStudentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "getAllStudentsResponse")
    public JAXBElement<GetAllStudentsResponse> createGetAllStudentsResponse(GetAllStudentsResponse value) {
        return new JAXBElement<GetAllStudentsResponse>(_GetAllStudentsResponse_QNAME, GetAllStudentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStudentAvatar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "getStudentAvatar")
    public JAXBElement<GetStudentAvatar> createGetStudentAvatar(GetStudentAvatar value) {
        return new JAXBElement<GetStudentAvatar>(_GetStudentAvatar_QNAME, GetStudentAvatar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FilterByFacultyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "filterByFacultyResponse")
    public JAXBElement<FilterByFacultyResponse> createFilterByFacultyResponse(FilterByFacultyResponse value) {
        return new JAXBElement<FilterByFacultyResponse>(_FilterByFacultyResponse_QNAME, FilterByFacultyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddStudent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "addStudent")
    public JAXBElement<AddStudent> createAddStudent(AddStudent value) {
        return new JAXBElement<AddStudent>(_AddStudent_QNAME, AddStudent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddGradeToStudentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "addGradeToStudentResponse")
    public JAXBElement<AddGradeToStudentResponse> createAddGradeToStudentResponse(AddGradeToStudentResponse value) {
        return new JAXBElement<AddGradeToStudentResponse>(_AddGradeToStudentResponse_QNAME, AddGradeToStudentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllStudents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "getAllStudents")
    public JAXBElement<GetAllStudents> createGetAllStudents(GetAllStudents value) {
        return new JAXBElement<GetAllStudents>(_GetAllStudents_QNAME, GetAllStudents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteStudentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "deleteStudentResponse")
    public JAXBElement<DeleteStudentResponse> createDeleteStudentResponse(DeleteStudentResponse value) {
        return new JAXBElement<DeleteStudentResponse>(_DeleteStudentResponse_QNAME, DeleteStudentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FilterByFaculty }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "filterByFaculty")
    public JAXBElement<FilterByFaculty> createFilterByFaculty(FilterByFaculty value) {
        return new JAXBElement<FilterByFaculty>(_FilterByFaculty_QNAME, FilterByFaculty.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddStudentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "addStudentResponse")
    public JAXBElement<AddStudentResponse> createAddStudentResponse(AddStudentResponse value) {
        return new JAXBElement<AddStudentResponse>(_AddStudentResponse_QNAME, AddStudentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteStudent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "deleteStudent")
    public JAXBElement<DeleteStudent> createDeleteStudent(DeleteStudent value) {
        return new JAXBElement<DeleteStudent>(_DeleteStudent_QNAME, DeleteStudent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddGradeToStudent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "addGradeToStudent")
    public JAXBElement<AddGradeToStudent> createAddGradeToStudent(AddGradeToStudent value) {
        return new JAXBElement<AddGradeToStudent>(_AddGradeToStudent_QNAME, AddGradeToStudent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateStudentFaculty }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://soap.soa.agh.edu.pl/", name = "updateStudentFaculty")
    public JAXBElement<UpdateStudentFaculty> createUpdateStudentFaculty(UpdateStudentFaculty value) {
        return new JAXBElement<UpdateStudentFaculty>(_UpdateStudentFaculty_QNAME, UpdateStudentFaculty.class, null, value);
    }

}
