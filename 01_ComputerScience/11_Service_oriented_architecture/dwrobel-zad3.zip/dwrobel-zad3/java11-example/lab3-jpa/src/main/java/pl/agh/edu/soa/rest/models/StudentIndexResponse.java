package pl.agh.edu.soa.rest.models;

public class StudentIndexResponse {

    private long id;
    private String indexNumber;

    public StudentIndexResponse() {
    }

    public StudentIndexResponse(long id, String indexNumber) {
        this.id = id;
        this.indexNumber = indexNumber;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getIndexNumber() {
        return indexNumber;
    }

    public void setIndexNumber(String indexNumber) {
        this.indexNumber = indexNumber;
    }
}
