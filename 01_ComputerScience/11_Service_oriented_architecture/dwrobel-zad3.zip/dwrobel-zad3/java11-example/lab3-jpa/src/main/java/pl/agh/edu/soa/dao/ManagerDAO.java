package pl.agh.edu.soa.dao;

import pl.agh.edu.soa.models.manytomany.Author;
import pl.agh.edu.soa.models.manytomany.Book;
import pl.agh.edu.soa.models.onetomany.Course;
import pl.agh.edu.soa.models.onetomany.Rating;
import pl.agh.edu.soa.models.onetoonebidirect.Student;
import pl.agh.edu.soa.models.onetoonebidirect.StudentsAlbum;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;
import java.util.List;

@Stateless
public class ManagerDAO {

    @PersistenceContext(unitName = "primary")
    EntityManager entityManager;

    public void createStudent(String name, String index) {
        Student s = new Student(name);
        StudentsAlbum sa = new StudentsAlbum();
        sa.setIndexNumber(index);
        s.setStudentsAlbum(sa);
        entityManager.persist(s);
    }

    public void createCourse(String name, List<Rating> ratings) {
        System.out.println("Course name: " + name);
        ratings.forEach(System.out::println);
        Course c = new Course();
        c.setName(name);
        for(Rating r : ratings){
            c.addRating(r.getRating());
        }
        entityManager.persist(c);
    }

    public List<Student> getStudents(){
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Student> criteriaQuery = criteriaBuilder.createQuery(Student.class);

        Root<Student> s = criteriaQuery.from(Student.class);
        CriteriaQuery<Student> all = criteriaQuery.select(s);

        List<Student> sl = entityManager
                .createQuery(all).getResultList();
        return sl;
    }

    public List<StudentsAlbum> getAlbums(){
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StudentsAlbum> criteriaQuery = criteriaBuilder.createQuery(StudentsAlbum.class);

        Root<StudentsAlbum> s = criteriaQuery.from(StudentsAlbum.class);
        CriteriaQuery<StudentsAlbum> all = criteriaQuery.select(s);

        List<StudentsAlbum> sl = entityManager
                .createQuery(all).getResultList();
        return sl;
    }



    @Transactional
    public List<Course> getCourses(){
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Course> criteriaQuery = criteriaBuilder.createQuery(Course.class);

        Root<Course> s = criteriaQuery.from(Course.class);
        CriteriaQuery<Course> all = criteriaQuery.select(s);

        List<Course> sl = entityManager
                .createQuery(all).getResultList();
        return sl;
    }


    public void createAuthor(Author author) {
        System.out.println(author);
        entityManager.persist(author);
    }

    public void createBook(Book book) {
        System.out.println(book);
        entityManager.persist(book);
    }



    @Transactional
    public Author getAuthor(int authorId){
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Author> criteriaQuery = criteriaBuilder.createQuery(Author.class);

        Root<Author> s = criteriaQuery.from(Author.class);
        criteriaQuery.where(criteriaBuilder.equal(s.get("id"), authorId));

        Author sl = entityManager
                .createQuery(criteriaQuery).getSingleResult();
        return sl;
    }

    @Transactional
    public List<Author> getAuthors(String genre){
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Author> criteriaQuery = criteriaBuilder.createQuery(Author.class);

        Root<Author> s = criteriaQuery.from(Author.class);
        if(!genre.equals("all")){
            criteriaQuery.where(criteriaBuilder.equal(s.get("genre"), genre));
        }

        List<Author> sl = entityManager
                .createQuery(criteriaQuery).getResultList();
        return sl;
    }

    @Transactional
    public Book getBook(int bookId){
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Book> criteriaQuery = criteriaBuilder.createQuery(Book.class);

        Root<Book> s = criteriaQuery.from(Book.class);
        criteriaQuery.where(criteriaBuilder.equal(s.get("id"), bookId));
        System.out.println("TRYING FETCHINIG TRYING FETCHING");
        Book sl = entityManager
                .createQuery(criteriaQuery).getSingleResult();
        System.out.println("Returing " + sl);
        return sl;
    }


}