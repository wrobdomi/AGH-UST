package pl.agh.edu.soa.rest.models;

import pl.agh.edu.soa.models.onetomany.Rating;

import java.util.List;

public class CourseREST {

    private String name;
    private List<Rating> ratings;

    public CourseREST() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Rating> getRatings() {
        return ratings;
    }

    public void setRatings(List<Rating> ratings) {
        this.ratings = ratings;
    }
}
