package pl.agh.edu.soa.rest.models;

public class StudentREST {

    private String name;
    private String index;

    public StudentREST() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }
}
