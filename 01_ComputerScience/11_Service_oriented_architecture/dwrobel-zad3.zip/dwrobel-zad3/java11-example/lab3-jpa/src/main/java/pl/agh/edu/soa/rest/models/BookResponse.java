package pl.agh.edu.soa.rest.models;

import java.io.Serializable;
import java.util.List;

public class BookResponse implements Serializable {

    private long id;
    private String title;
    private List<BooksAuthorsResponse> booksAuthorsResponses;

    public BookResponse() {
    }

    public BookResponse(long id, String title, List<BooksAuthorsResponse> booksAuthorsResponses) {
        this.id = id;
        this.title = title;
        this.booksAuthorsResponses = booksAuthorsResponses;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<BooksAuthorsResponse> getBooksAuthorsResponses() {
        return booksAuthorsResponses;
    }

    public void setBooksAuthorsResponses(List<BooksAuthorsResponse> booksAuthorsResponses) {
        this.booksAuthorsResponses = booksAuthorsResponses;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "BookResponse{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", booksAuthorsResponses=" + booksAuthorsResponses +
                '}';
    }
}
