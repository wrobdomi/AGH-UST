package pl.agh.edu.soa.rest.models;

import java.io.Serializable;

public class StudentResponse implements Serializable {

    private long id;
    private String name;
    private StudentIndexResponse studentIndexResponse;

    public StudentResponse() {
    }

    public StudentResponse(long id, String name, StudentIndexResponse studentIndexResponse) {
        this.id = id;
        this.name = name;
        this.studentIndexResponse = studentIndexResponse;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public StudentIndexResponse getStudentIndexResponse() {
        return studentIndexResponse;
    }

    public void setStudentIndexResponse(StudentIndexResponse studentIndexResponse) {
        this.studentIndexResponse = studentIndexResponse;
    }
}
