package pl.agh.edu.soa.rest;

import pl.agh.edu.soa.dao.ManagerDAO;
import pl.agh.edu.soa.models.manytomany.Author;
import pl.agh.edu.soa.models.manytomany.Book;
import pl.agh.edu.soa.models.onetomany.Course;
import pl.agh.edu.soa.models.onetoonebidirect.Student;
import pl.agh.edu.soa.models.onetoonebidirect.StudentsAlbum;
import pl.agh.edu.soa.rest.models.*;

import javax.ejb.EJB;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.LinkedList;
import java.util.List;

// localhost:8080/lab1-web/zad2/jpa/students
@Path("/jpa")
public class RestAPI {

    @EJB
    ManagerDAO managerDAO;

    // ONE-TO-ONE bidirectional -------------------------------------- //
    @POST
    @Path("/students")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createStudent(StudentREST studentREST){
        managerDAO.createStudent(studentREST.getName(), studentREST.getIndex());
        return Response.status(Response.Status.CREATED).build();
    }

    // BLAD PRZY GET - referencja typu cyclic (bidirectional)
    @GET
    @Path("/students")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudents() {
        List<Student> students = managerDAO.getStudents();
        List<StudentResponse> studentResponses = new LinkedList<>();
        for(Student s : students){
            StudentIndexResponse sir = new StudentIndexResponse(
                    s.getStudentsAlbum().getId(),
                    s.getStudentsAlbum().getIndexNumber()
            );
            studentResponses.add(new StudentResponse(s.getId(), s.getName(), sir));
        }
        System.out.println("Students are: ");
        students.forEach(System.out::println);
        return Response.ok(studentResponses).build();
    }


    // BLAD PRZY GET - referencja typu cyclic (bidirectional)
    @GET
    @Path("/albums")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAlbums() {
        List<StudentsAlbum> studentsAlbums = managerDAO.getAlbums();
        List<AlbumResponse> albumResponses = new LinkedList<>();
        for(StudentsAlbum sa : studentsAlbums){
            AlbumStudentsResponse asr = new AlbumStudentsResponse(
                    sa.getStudent().getId(),
                    sa.getStudent().getName()
            );
            albumResponses.add(new AlbumResponse(sa.getId(), sa.getIndexNumber(), asr));
        }
        return Response.ok(albumResponses).build();
    }

    // -------------------------------------------------------------- //


    // ONE-TO-MANY -------------------------------------------------- //
    @POST
    @Path("/courses")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createCourse(CourseREST courseREST){
        managerDAO.createCourse(courseREST.getName(), courseREST.getRatings());
        return Response.status(Response.Status.CREATED).build();
    }

    @GET
    @Path("/courses")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getCourses() {
        List<Course> courses = managerDAO.getCourses();
        System.out.println("Courses are: ");
        courses.forEach(System.out::println);
        return Response.ok(courses).build();
    }

    // MANY-TO-MANY ------------------------------------------------- //
    // ONE-TO-MANY -------------------------------------------------- //
    @POST
    @Path("/authors")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createAuthor(Author author){
        managerDAO.createAuthor(author);
        return Response.status(Response.Status.CREATED).build();
    }

    @POST
    @Path("/books")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createBook(Book book){
        managerDAO.createBook(book);
        return Response.status(Response.Status.CREATED).build();
    }


    @GET
    @Path("/books/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBook(@PathParam("id") int id) {
        Book book = managerDAO.getBook(id);
        System.out.println("Book is " + book);
        List<BooksAuthorsResponse> booksAuthorsResponses = new LinkedList<>();
        for(Author a : book.getAuthors()){
            booksAuthorsResponses.add(new BooksAuthorsResponse(a.getId(), a.getName(), a.getGenre()));
        }
        BookResponse bookResponse = new BookResponse(book.getId(), book.getTitle(), booksAuthorsResponses);
        System.out.println("Response is " + bookResponse);
        return Response.ok(bookResponse).build();
    }

    @GET
    @Path("/authors/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAuthor(@PathParam("id") int id) {
        Author author = managerDAO.getAuthor(id);
        List<AuthorBooksResponse> authorBooksResponses = new LinkedList<>();
        for(Book b : author.getBooks()){
            authorBooksResponses.add(new AuthorBooksResponse(b.getId(), b.getTitle()));
        }
        AuthorResponse authorResponse = new AuthorResponse(
                author.getId(),
                author.getName(),
                author.getGenre(),
                authorBooksResponses);
        return Response.ok(authorResponse).build();
    }



    @GET
    @Path("/authors")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAuthors(@DefaultValue("all") @QueryParam("genre") String genre){

        List<Author> authors = managerDAO.getAuthors(genre);
        List<AuthorResponse> authorResponses = new LinkedList<>();

        for(Author a : authors) {
            List<AuthorBooksResponse> authorBooksResponses = new LinkedList<>();
            for (Book b : a.getBooks()) {
                authorBooksResponses.add(new AuthorBooksResponse(b.getId(), b.getTitle()));
            }
            AuthorResponse authorResponse = new AuthorResponse(
                    a.getId(),
                    a.getName(),
                    a.getGenre(),
                    authorBooksResponses);
            authorResponses.add(authorResponse);
        }
        return Response.ok(authorResponses).build();
    }



}
