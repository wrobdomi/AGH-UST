package pl.agh.edu.soa.models.onetoonebidirect;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="students")
public class Student implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name="name")
    private String name;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="id")
    private StudentsAlbum studentsAlbum;

    public Student() {
    }

    public Student(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public StudentsAlbum getStudentsAlbum() {
        return studentsAlbum;
    }

    public void setStudentsAlbum(StudentsAlbum studentsAlbum) {
        this.studentsAlbum = studentsAlbum;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", studentsAlbum=" + studentsAlbum +
                '}';
    }
}
