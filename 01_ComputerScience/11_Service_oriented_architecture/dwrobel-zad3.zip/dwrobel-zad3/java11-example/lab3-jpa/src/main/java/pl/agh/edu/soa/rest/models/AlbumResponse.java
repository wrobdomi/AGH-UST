package pl.agh.edu.soa.rest.models;

import java.io.Serializable;

public class AlbumResponse implements Serializable {

    private long id;
    private String indexNumber;
    private AlbumStudentsResponse albumStudentsResponse;

    public AlbumResponse() {
    }

    public AlbumResponse(long id, String indexNumber, AlbumStudentsResponse albumStudentsResponse) {
        this.id = id;
        this.indexNumber = indexNumber;
        this.albumStudentsResponse = albumStudentsResponse;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getIndexNumber() {
        return indexNumber;
    }

    public void setIndexNumber(String indexNumber) {
        this.indexNumber = indexNumber;
    }

    public AlbumStudentsResponse getAlbumStudentsResponse() {
        return albumStudentsResponse;
    }

    public void setAlbumStudentsResponse(AlbumStudentsResponse albumStudentsResponse) {
        this.albumStudentsResponse = albumStudentsResponse;
    }
}
