package pl.agh.edu.soa.models.onetomany;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="ratings")
public class Rating implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private long id;

    @Column(name="rating")
    private String rating;

    public Rating() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Rating{" +
                "id=" + id +
                ", rating='" + rating + '\'' +
                '}';
    }
}
