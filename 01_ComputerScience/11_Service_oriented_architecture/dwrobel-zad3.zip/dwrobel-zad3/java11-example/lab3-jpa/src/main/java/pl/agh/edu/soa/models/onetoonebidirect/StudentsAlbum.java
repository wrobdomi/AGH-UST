package pl.agh.edu.soa.models.onetoonebidirect;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="students_albums")
public class StudentsAlbum implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private long id;

    @Column(name="index_number")
    private String indexNumber;

    @OneToOne(mappedBy = "studentsAlbum", cascade = CascadeType.ALL)
    private Student student;

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public StudentsAlbum() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getIndexNumber() {
        return indexNumber;
    }

    public void setIndexNumber(String indexNumber) {
        this.indexNumber = indexNumber;
    }

    @Override
    public String toString() {
        return "StudentsAlbum{" +
                "studentsAlbumId=" + id +
                ", indexNumber='" + indexNumber + '\'' +
                '}';
    }
}
