package pl.edu.agh.soa.soap;

import org.apache.commons.codec.binary.Base64;
import org.jboss.ejb3.annotation.SecurityDomain;
import pl.edu.agh.soa.models.Grade;
import pl.edu.agh.soa.models.Student;
import pl.edu.agh.soa.models.StudentsSoap;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.imageio.ImageIO;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;

// WSDL:
// http://localhost:8080/lab1-ejb/HelloWorld?wsdl
@Stateless
@WebService
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
@SecurityDomain("other") // references studentsDomain
@RolesAllowed("{programmer, guest}")
public class HelloWorld {

    @XmlElementWrapper(name="students_list")
    @XmlElement(name="students")
    StudentsSoap studentsSoap = new StudentsSoap();

    /**
     * get all students
     */
    @WebMethod
    @WebResult(name="students_list")
    @PermitAll
    public StudentsSoap getAllStudents(){
        return studentsSoap;
    }

    /**
     * add new student
     * the endpoint is available only for programmer role
     */
    @WebMethod
    @RolesAllowed("programmer")
    public String addStudent(
            @WebParam(name = "name") String name,
            @WebParam(name = "surname") String surname,
            @WebParam(name = "indexNumber") String indexNumber,
            @WebParam(name = "faculty") String faculty){
        Student newStudent = new Student(name, surname, indexNumber, faculty);
        studentsSoap.students.add(newStudent);
        return "Student added successfully";
    }

    /**
     * add grade to specific student
     */
    @WebMethod
    public String addGradeToStudent(
            @WebParam(name = "indexNumber") String indexNum,
            @WebParam(name = "subject") String subject,
            @WebParam(name = "value") double value
    ) {
        Grade newGrade = new Grade(subject, value);
        Student student = studentsSoap.students.stream()
                .filter(s -> s.indexNumber.equals(indexNum))
                .findAny()
                .orElse(null);
        student.grades.add(newGrade);
        return "Grade added successfully";
    }

    /**
     * update students faculty
     */
    @WebMethod
    public String updateStudentFaculty(
            @WebParam(name = "indexNumber") String indexNum,
            @WebParam(name = "newFaculty") String newFaculty
    ){
        Student student = studentsSoap.students.stream()
                .filter(s -> s.indexNumber.equals(indexNum))
                .findAny()
                .orElse(null);
        student.faculty = newFaculty;
        return "Faculty updated successfully";
    }

    /**
     * delete student
     */
    @WebMethod
    public String deleteStudent(
            @WebParam(name = "indexNumber") String indexNum
    ){
        studentsSoap.students.removeIf(s -> s.indexNumber.equals(indexNum));
        return "Student deleted successfully";
    }

    /**
     * filter by faculty
     */
    @WebMethod
    public StudentsSoap filterByFaculty(@WebParam(name = "facultyName") String facultyName) {
        StudentsSoap filteredStudentsSoap = new StudentsSoap();
        filteredStudentsSoap.students = new ArrayList<>();
        filteredStudentsSoap.students.addAll(this.studentsSoap.students.stream()
                                                        .filter(s -> s.faculty.equals(facultyName))
                                                        .collect(Collectors.toList()) );
        return filteredStudentsSoap;
    }


    /**
     * get encoded student avatar
     */
    @WebMethod
    public String getStudentAvatar(@WebParam(name="indexNum") String indexNum) {

        BufferedImage image = null;
        try {
            image = ImageIO.read(new File(
//                    "..\\..\\..\\..\\..\\resources\\avatar.png"
                    "C:\\Users\\Dominik\\Desktop\\SOA\\Laboratorium_Rozwiązania\\Lab1_Rozwiazanie\\java11-example\\java11-example\\lab1-ejb\\src\\main\\resources\\avatar.png"
            ));
        }
        catch (IOException ioexception){
            System.out.println("Can not find avatar");
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        try {
            ImageIO.write(image, "png", outputStream);
        }
        catch (IOException ioexception){
            System.out.println("Can not write avatar");
        }

        Base64 base64 = new Base64();
        String encodedImage = new String(base64.encodeBase64(outputStream.toByteArray()));

        return encodedImage;
    }

}
