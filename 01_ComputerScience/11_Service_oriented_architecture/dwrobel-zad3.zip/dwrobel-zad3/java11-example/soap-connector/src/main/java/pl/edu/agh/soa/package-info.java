@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.soa.agh.edu.pl/")
package pl.edu.agh.soa;
