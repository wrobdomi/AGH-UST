package pl.agh.edu.soa.rest;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.commons.codec.binary.Base64;
import pl.agh.edu.soa.jwt.JWTTokenRequired;
import pl.agh.edu.soa.jwt.KeyGenerator;
import pl.agh.edu.soa.models.Student;
import pl.agh.edu.soa.models.StudentREST;
import pl.agh.edu.soa.models.StudentsList;
import pl.agh.edu.soa.models.UserModel;

import javax.imageio.ImageIO;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.security.Key;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Random;
import java.util.stream.Collectors;

@Path("/rest")
public class StudentsController {

    @Inject
    private KeyGenerator keyGenerator;

    @Context
    private UriInfo uriInfo;

    /**
     * get auth token, the token is required for
     * all POST, PUT and DELETE requests
     * @param userModel contains uer login
     * @return JWT token as AUTHORIZATION header
     */
    @POST
    @Path("/gettoken")
    public Response getJWTToken(UserModel userModel){

        System.out.println("Username is " + userModel.getLogin());

        Key key = keyGenerator.generateKey();
        String token = Jwts.builder()
                .setSubject(userModel.getLogin())
                .setIssuer(uriInfo.getAbsolutePath().toString())
                .setIssuedAt(new Date())
                .setExpiration(toDate(LocalDateTime.now().plusMinutes(15L)))
                .signWith(SignatureAlgorithm.HS512, key)
                .compact();

        return Response.ok().header(HttpHeaders.AUTHORIZATION, "Bearer " + token).build();
    }

    /**
     * get all students, client can filter by faculty
     * @return list of students
     */
    @GET
    @Path("/students")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudents(@DefaultValue("all") @QueryParam("faculty") String faculty){

        System.out.println("Faculty is " + faculty);
        // HTTP status code 200
        if(faculty.equals("all")){
            return Response.ok(StudentsList.students).build();
        }
        return Response.ok(
                StudentsList.students
                        .stream()
                        .filter(s -> s.getFaculty().equals(faculty))
                        .collect(Collectors.toList())
        ).build();
    }

    /**
     * get specific students
     * @param id students id
     * @return student
     */
    @GET
    @Path("/students/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudent(@PathParam("id") int id) {
        Student student = StudentsList.students.stream().filter(s -> s.getId() == id).findAny().orElse(null);
        System.out.println("Student is " + student);
        if(student != null){
          // HTTP status code 200
          return Response.ok(student).build();
        }
        // if student not found, HTTP status code 404
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    /**
     * get students grades
     * @param id students id
     * @return list of students grades
     */
    @GET
    @Path("/students/{id}/grades")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudentsGrades(@PathParam("id") int id){
        Student student = StudentsList.students.stream().filter(s -> s.getId() == id).findAny().orElse(null);
        System.out.println("Student is " + student);
        if(student != null){
            // HTTP status code 200
            return Response.ok(student.getGrades()).build();
        }
        // if student not found, HTTP status code 404
        return Response.status(Response.Status.NOT_FOUND).build();
    }


    /**
     * the operation return binary data, students avatar
     * @param id students id
     * @return students avatar
     */
    @GET
    @Path("/students/{id}/avatars")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getStudentsAvatar(@PathParam("id") int id){
        Student student = StudentsList.students.stream().filter(s -> s.getId() == id).findAny().orElse(null);
        System.out.println("Student is " + student);
        if(student == null){
            // if student not found, HTTP status code 404
            return Response.status(Response.Status.NOT_FOUND).build();
        }


        BufferedImage image = null;
        try {
            image = ImageIO.read(new File(
//                    "..\\..\\..\\..\\..\\resources\\avatar.png"
                    "C:\\Users\\Dominik\\Desktop\\SOA\\Laboratorium_Rozwiązania\\dwrobel-zad2\\java11-example\\rest-api\\src\\main\\webapp\\avatar.png"
            ));
        }
        catch (IOException ioexception){
            System.out.println("Can not find avatar");
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        try {
            ImageIO.write(image, "png", outputStream);
        }
        catch (IOException ioexception){
            System.out.println("Can not write avatar");
        }

        Base64 base64 = new Base64();
        String encodedImage = new String(base64.encodeBase64(outputStream.toByteArray()));

        // HTTP status code 200
        return Response.ok(encodedImage).build();

    }

    /**
     * add student
     * @param studentREST students details
     * @return 201 if created, 400 if not valid
     */
    @POST
    @JWTTokenRequired  // if not authenticated, HTTP status 401
    @Path("/students") // if not valid, HTTP status 400
    public Response createStudent(@Valid StudentREST studentREST){
        Random r = new Random();
        Student s = new Student(
                10 + r.nextInt(100),
                studentREST.getName(),
                studentREST.getSurname(),
                studentREST.getFaculty()
        );

        StudentsList.students.add(s);

        // HTTP status 201
        return Response.status(Response.Status.CREATED).build();
    }

    /**
     * update student
     * @param id students id
     * @param studentREST students details
     * @return 204 if updated, 400 if not valid
     */
    @PUT
    @JWTTokenRequired
    @Path("/students/{id}")
    public Response updateStudent(@PathParam("id") int id, @Valid StudentREST studentREST){

        Student s1 = StudentsList.students.stream().filter(s -> s.getId() == id).findFirst().orElse(null);

        if(s1 == null){
            // if student not found, HTTP status code 404
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        s1.setFaculty(studentREST.getFaculty());
        s1.setName(studentREST.getName());
        s1.setSurname(studentREST.getSurname());

        // HTTP status 204
        return Response.status(Response.Status.NO_CONTENT).build();
    }

    /**
     * remove student
     * @param id students id
     * @return 204 if removed, 404 if not found
     */
    @DELETE
    @JWTTokenRequired
    @Path("/students/{id}")
    public Response deleteStudent(@PathParam("id") int id){

        Student s1 = StudentsList.students.stream().filter(s -> s.getId() == id).findFirst().orElse(null);

        if(s1 == null){
            // if student not found, HTTP status code 404
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        StudentsList.students.remove(s1);

        // HTTP status 204
        return Response.status(Response.Status.NO_CONTENT).build();
    }


    /**
     * helper method for date conversion
     * @param localDateTime
     * @return
     */
    private Date toDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

//    @GET
//    @Path("/test")
//    @JWTTokenRequired
//    public String testMe(){
//        return "JWT test";
//    }

}
