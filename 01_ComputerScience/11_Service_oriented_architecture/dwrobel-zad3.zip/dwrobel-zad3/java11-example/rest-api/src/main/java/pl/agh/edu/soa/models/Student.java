package pl.agh.edu.soa.models;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Student {

    private int id;
    private String name;
    private String surname;
    private String faculty;
    private List<Grade> grades;

    public Student(int id, String name, String surname, String faculty) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.faculty = faculty;
        grades = new LinkedList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public List<Grade> getGrades() {
        return grades;
    }

    public void setGrades(List<Grade> grades) {
        this.grades = grades;
    }

    public void addGrade(Grade g){
        this.grades.add(g);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return id == student.id &&
                Objects.equals(name, student.name) &&
                Objects.equals(surname, student.surname) &&
                Objects.equals(faculty, student.faculty);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, surname, faculty);
    }
}
