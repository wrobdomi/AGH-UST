package pl.agh.edu.soa.jwt;

import java.security.Key;

public interface KeyGenerator {
    Key generateKey();
}
