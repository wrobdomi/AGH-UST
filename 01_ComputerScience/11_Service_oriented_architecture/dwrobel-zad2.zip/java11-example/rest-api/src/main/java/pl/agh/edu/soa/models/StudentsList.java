package pl.agh.edu.soa.models;

import java.util.LinkedList;
import java.util.List;

public class StudentsList {

    public static List<Student> students;

    static{
        students  = new LinkedList<>();
        Student s1 = new Student(1, "Dominik", "Wrobel", "EAIIB");
        s1.addGrade(new Grade("Maths", 5));
        s1.addGrade(new Grade("Physics", 4));
        Student s2 = new Student(2, "Zosia", "Kowalska", "IMIR");
        s2.addGrade(new Grade("Mechanics", 4));
        s2.addGrade(new Grade("Robotics", 5));
        Student s3 = new Student(3, "Marcin", "Nowak", "WIMIP");
        s3.addGrade(new Grade("Materials", 5));
        Student s4 = new Student(4, "Kamil", "Sosnowski", "EAIIB");
        s4.addGrade(new Grade("Electronics", 5));
        s4.addGrade(new Grade("Programming", 5));
        Student s5 = new Student(5, "Monika", "Zalewska", "IMIR");
        s5.addGrade(new Grade("Mechanics", 3));
        s5.addGrade(new Grade("Robotics", 3));
        Student s6 = new Student(6, "Anna", "Wesolowska", "WIMIP");
        s6.addGrade(new Grade("Meterials", 4));
        s6.addGrade(new Grade("Automation", 5));
        students.add(s1);
        students.add(s2);
        students.add(s3);
        students.add(s4);
        students.add(s5);
        students.add(s6);
    }

    public StudentsList() {
    }
}
