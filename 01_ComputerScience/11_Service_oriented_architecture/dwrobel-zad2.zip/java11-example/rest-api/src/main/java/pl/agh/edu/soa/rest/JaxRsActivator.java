package pl.agh.edu.soa.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/zad2")
public class JaxRsActivator extends Application {
}
