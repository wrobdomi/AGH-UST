package pl.edu.agh.soa.models;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Student {

    @XmlElement
    public String name;

    @XmlElement
    public String surname;

    @XmlElement
    public String indexNumber;

    @XmlElement
    public String faculty;

    @XmlElementWrapper(name="grades_list")
    @XmlElement(name="grade")
    public List<Grade> grades;

    public Student(String name, String surname, String indexNumber, String faculty) {
        this.name = name;
        this.surname = surname;
        this.indexNumber = indexNumber;
        this.faculty = faculty;
        grades = new ArrayList<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return Objects.equals(name, student.name) &&
                Objects.equals(surname, student.surname) &&
                Objects.equals(indexNumber, student.indexNumber);
    }

    @Override
    public int hashCode() {

        return Objects.hash(name, surname, indexNumber);
    }
}
