
package pl.edu.agh.soa;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getAllStudentsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getAllStudentsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="students_list" type="{http://soap.soa.agh.edu.pl/}studentsSoap" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAllStudentsResponse", propOrder = {
    "studentsList"
})
public class GetAllStudentsResponse {

    @XmlElement(name = "students_list")
    protected StudentsSoap studentsList;

    /**
     * Gets the value of the studentsList property.
     * 
     * @return
     *     possible object is
     *     {@link StudentsSoap }
     *     
     */
    public StudentsSoap getStudentsList() {
        return studentsList;
    }

    /**
     * Sets the value of the studentsList property.
     * 
     * @param value
     *     allowed object is
     *     {@link StudentsSoap }
     *     
     */
    public void setStudentsList(StudentsSoap value) {
        this.studentsList = value;
    }

}
