package pl.edu.agh.soa.models;

import javax.validation.constraints.NotNull;

public class StudentREST {

    @NotNull
    private String name;

    @NotNull
    private String surname;

    @NotNull
    private String faculty;


    public StudentREST() {
    }

    public StudentREST(String name, String surname, String faculty) {
        this.name = name;
        this.surname = surname;
        this.faculty = faculty;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }
}
