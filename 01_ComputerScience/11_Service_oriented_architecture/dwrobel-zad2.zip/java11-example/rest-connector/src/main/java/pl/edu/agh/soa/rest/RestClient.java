package pl.edu.agh.soa.rest;

import pl.edu.agh.soa.models.Grade;
import pl.edu.agh.soa.models.Student;
import pl.edu.agh.soa.models.StudentREST;
import pl.edu.agh.soa.models.UserModel;

import javax.imageio.ImageIO;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;

@Path("/client")
public class RestClient {

    private static String baseURL = "http://localhost:8080/lab1-web/zad2/rest";

    @GET
    @Path("/test")
    public void connectToREST() throws IOException {

        Client client = ClientBuilder.newClient();

        // wywolanie metody listujacej klasy modelu i konwersja JSON na obiekty Javy ------------------------ //
        System.out.println("Getting list of students...");
        WebTarget myResource = client.target(baseURL + "/students/1");
        Response r1 = myResource
                .request(MediaType.APPLICATION_JSON)
                .get(Response.class);

        System.out.println("Status code is " + r1.getStatus());
        Student s = r1.readEntity(Student.class);
        System.out.println("Student with id 1: ");
        System.out.println(s.getName() + " " + s.getSurname() + " " + s.getFaculty());
        System.out.println("Grades: ");
        for(Grade g : s.getGrades()){
            System.out.println(g.getSubject() + ": " + g.getGrade());
        }

        // wywolanie metody wymagajacej autoryzacji --------------------------------------------------------- //
        WebTarget authTokenResource = client.target(baseURL + "/gettoken");
        UserModel userModel = new UserModel("login");
        Response r2 = authTokenResource
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.entity(userModel, MediaType.APPLICATION_JSON));

        System.out.println("Auth status response " + r2.getStatus());
        String token = r2.getHeaderString(HttpHeaders.AUTHORIZATION);
//        String justTheToken = token.substring("Bearer".length()).trim();

        WebTarget myResourcePost = client.target(baseURL + "/students");
        StudentREST sr = new StudentREST("TestName", "TestSurname", "EAIIB");
        Response r3 = myResourcePost
                .request(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, token)
                .post(Entity.entity(sr, MediaType.APPLICATION_JSON));

        System.out.println("Post status response " + r3.getStatus());

        // wywolanie metody zwracajacej dane binarne ------------------------------------------------------- //
        WebTarget resourceAvatar = client.target(baseURL + "/students/1/avatars");
        Response r4 = resourceAvatar
                .request(MediaType.APPLICATION_JSON)
                .get(Response.class);
        String encodedImage = r4.readEntity(String.class);
        byte[] decodedImage= Base64.getDecoder().decode(encodedImage);
        ByteArrayInputStream bytesArr = new ByteArrayInputStream(decodedImage);
        BufferedImage bImage = ImageIO.read(bytesArr);
        ImageIO.write(bImage, "png", new File(
                "C:\\Users\\Dominik\\Desktop\\SOA\\Laboratorium_Rozwiązania\\dwrobel-zad2\\java11-example\\rest-connector\\src\\main\\resources\\avatarrr.png"
        ) );

    }


}
